print("Verificar si un número está en un rango.")
print("=======================================\n")

numero = int(input('escribe un numero: '))

if numero>=1 and numero<=100:
	print(f'el numero {numero} esta dentro del rango')
	
else:
	print(f'el numero {numero} no esta dentro del rango')