print("Verificar si un número es múltiplo de 5:")
print("=======================================\n")
	
num = int(input("agrega un numero entero: "))
if num % 5==0:
	print("el numero es multiplo de 5")

else:
	print("no es multiplo de 5")