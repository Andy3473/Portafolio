print("Pide al usuario un número entero positivo y muestra todos los números del 1 hasta  ese número usando un ciclo while.")
print("----------------------------------------------------------------------------------\n")

x = 1
z = float(input("ingrese un numero positivo: "))
while x <= z:
	print(x)
	x += 1