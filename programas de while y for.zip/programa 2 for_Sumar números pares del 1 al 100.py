print("Escribe un programa que sume todos los números pares del 1 al 100 usando un ciclo for")
print("----------------------------------------------------------------------------------\n")

suma = 0
for i in range(1,100):
	suma += i
print(f"la suma de los numeros pares: {suma}")