print(" Imprime todos los números del 10 al 1 en orden descendente usando un ciclo for.")
print("-----------------------------------------------------------------------------------\n")

for n in range(10,0,-1):
	print(n)
	