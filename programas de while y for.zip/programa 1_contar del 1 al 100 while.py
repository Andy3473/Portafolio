print("Escribe un programa que sume todos los números del 1 al 100 usando un ciclo while")
print("----------------------------------------------------------------------------------\n")

x = 1
suma = 0
while x <= 100:
	suma = suma + x
	x += 1
print(f'la suma de los numeros del 1 al cien es de: {suma}')	