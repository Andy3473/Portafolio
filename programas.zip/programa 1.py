#Verificar si un número es positivo, negativo o cero
print("escribe el numero: ")
n = int(input())
if n>0:
	print("es positivo")
	
elif n<0:
	print("es negativo")

else:
	print("es cero")