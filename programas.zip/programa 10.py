#Escribe un programa que solicite al usuario #dos números y determine cuál es mayor o 
#si son iguales.

a = int(input("ingrese un numero: "))
b = int(input("ingrese un segundo numero: "))

if a == b:
	print("ambos son iguales")
elif a > b:
	print(f'el numero mañor es {a}')
	print(f'el numero menor es {b}')
elif a < b:
	print(f'el numero mañor es {b}')
	print(f'el numero menor es {a}')