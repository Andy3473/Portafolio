#Verificar si una palabra tiene más de 5 letras.

import re

extracto = input('escribe una palabra: ')
patron = r'\b\w{5}\b'

resultado = re.findall(patron,extracto)

print(len(resultado))

for p in resultado:
	print("la palabra tiene mas de 5 letras")
if p<5 or p>0:
	print("la palabra no tiene 5 letras")